# 07. Social Media Icons
------
Problems for in-class lab for the [“HTML & CSS”](https://softuni.bg/trainings/2375/html-and-css-may-2019) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1237/Position-and-Float).

## Tasks
* Create an **"index.html"** file with title - **Social Media Icons**
* All you need for your HTML are **ul**, **li** and **a** tags
* Use **fontawesome** to add social icons
* Change the ul **display** property to **inline-block**
* Remove list items style
* Each **a** tag must have border-radius **50%**
* When you **hover** the icons change the color